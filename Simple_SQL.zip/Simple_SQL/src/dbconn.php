<?php
  $conn = mysqli_connect('db','root', '123qwe','web_hacking');
  if (!$conn) 
    die("Connection failed: " . mysqli_connect_error());
?>
